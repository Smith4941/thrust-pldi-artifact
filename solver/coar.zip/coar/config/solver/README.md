# Solver configurations

Each file here is a solver entry point, selected with `-c` and run from the repository root (nested
configuration files are named relative to it). How a name reads:

- **No suffix** (`muval.json`, `muval_ppm.json`, `mustrat.json`, `pcsat.json`): the engine at CoAR's
  defaults. The file states only what differs from the code's defaults and follows them as they move.
- **The default** (no `-c`): `portfolio_muval_ppm_mustrat_muval_ppm.json` (`muval_ppm` for 10 s, then `mustrat`
  for 60 s, then `muval_ppm`) for `muclp` and `pltsterm` (the classes it was measured on),
  `portfolio_muval_qfl_native_deg1_muval.json` (`muval_qfl_native_deg1` -- MuVal's QFL solver with CoAR's own
  Farkas/Handelman PQE encoder, `pqe_native_deg1`, PolyQEnt's certificates built in CoAR -- to its answer, then `muval`
  only when it gave none) for `qfl`, `pgcl` and `sgcl` (since 2026-11-11, the maintainer's choice that evening;
  `portfolio_muval_qfl_polyqent_deg1_muval.json`, with the external PolyQEnt as the first stage, was the default on
  2026-11-10 and is an option; `?Omega` queries included, since that file's omega-regular
  certificate is LexPMSM, the same as `muval_qfl_omega_lexpmsm_polyqent_deg1`), `muval.json` for the others (`main.ml`'s
  `default_config_file`). Without the PCSat fallback, `-c muval_qfl_polyqent_deg1.json`.
- **`_popl27`** (`muval_ppm_popl27.json`, `muval_popl27.json`, `mustrat_popl27.json`): pinned for the
  POPL 2027 paper's runs. The file writes the paper's method explicitly (for `muval_ppm_popl27`,
  SCC-wise parity relations and alternation-depth priorities) and pins off any step that could decide
  an answer without that method, such as the ground-query solve before the reduction. Internal search
  defaults (how templates grow, the PCSat chain) still follow the code.
- **`_pldi27`** (`mucyc_stochastic_horn_pldi27.json`, `mucyc_stochastic_horn_weakest_pldi27.json`): pinned for the
  PLDI 2027 probabilistic-CHC paper's runs, the same rule as `_popl27`: the lower (Kleene) iteration raced beside the
  refinement search is off, since it refutes by the bounded evaluation the paper uses as its baseline; the interpolant
  portfolio and the one-step initialisation of unfolded nodes (`stochastic_horn_tighten`, within the paper's trace
  condition) follow the code and are stated in the paper's implementation section. Since 2026-11-13 both set
  `stochastic_horn_template_regions` (the lemma proposal reads draws over regions; DEFAULT_DECISIONS.md 2026-11-13) and `stochastic_horn_cancel`
  (density cancellation before integration; a judgement call on the paper's integration rule, same entry date).

- **`_pldi27`** (U-CHC: `mucyc_uchc_pldi27.json`): pinned for the PLDI 2027 U-CHC paper's column: `mucyc_uchc.json`
  with what the paper cannot explain turned off -- the ground-query solve (a separate parity-game solve before the
  procedure) -- and what it can explain as IC3/PDR practice kept on: relative induction, monotone frames, propagation,
  the lose/win cubes and regions (cube generalisation), and since 2026-11-12 night `uchc_constant_search` (inductive
  regions with constants of their own; DEFAULT_DECISIONS.md 2026-11-12), and since 2026-11-13
  `uchc_flat_disjunction_naming` (a disjunction under a universal named by one predicate rather than a chain; the same
  least solution, fewer levels per move; DEFAULT_DECISIONS.md 2026-11-13), which `mucyc_uchc.json` does not set yet;
  and since 2026-11-13 four fields off in the code (DEFAULT_DECISIONS.md 2026-11-13): the term selection over an
  implicant of formulas above 2048 atoms, and the cube pairing's one-sided differences and sums; and
  `uchc_lose_generalise_ints` (the inductive generalisation of a losing state's integer cube; DEFAULT_DECISIONS.md
  2026-11-13, the entry on that field). The maintainer's rule, 2026-11-12: methods
  foreign to the paper off, explainable refinements on. `mucyc_uchc.json` is the column of CoAR's default.
  portfolio, its CPU time slices (`stochastic_horn_portfolio_cpu_slice`, 0.25 s by default since 2026-11-12) and the
  one-step initialisation of unfolded nodes (`stochastic_horn_tighten`, within the paper's trace condition) follow the
  code and are stated in the paper's implementation section.
  condition) follow the code and are stated in the paper's implementation section. The callee-structure tightening
  and the water-level budget (`stochastic_horn_tighten_callee_structure`, `stochastic_horn_budget`) are off in the
  code and set only in `mucyc_stochastic_horn.json` (the default portfolio; DEFAULT_DECISIONS.md 2026-11-12), so the
  `_pldi27` files and the single-leaf configurations run without them. The density cancellation, the bracketed
  constant roots and the lower iteration's Park-induction candidates (`stochastic_horn_cancel`,
  `stochastic_horn_bracket`, `stochastic_horn_lower_candidates`) are off in the code and set in
  `mucyc_stochastic_horn.json` and `mucyc_stochastic_horn_weakest.json` only (DEFAULT_DECISIONS.md 2026-11-12).
- **`ablation/<base>_no_<feature>`**: an ablation arm, the base with an optimisation removed. Ablation
  arms follow the defaults and are never A/B'd; `ablation/README.md` lists each with its base.
- **Any other feature suffix**: a pinned feature set, or a component chain (`_tb_ar`, `_fixpoint`,
  ...), or an experiment arm of a past measurement. A name does not spell a default: `tbq_ar` is
  PCSat's default chain, so `pcsat_<feature>` is the default with that feature (`pcsat_nocell_mod2`),
  and `pcsat_tbq_*` without `_ar` is the non-default scalar-template chain. `_yesno` is MuVal's
  yes/no output with no iteration count (`muval_yesno`). MuVal's and MuStrat's inner PCSat defaults are
  `pcsat_muval` and `pcsat_mustrat`.
- **`mucyc_qsat_<return>[_entry_model]`**: MuCyc's QSMT search with the backtracking named by the level a
  lemma returns to (`backtrack_strategy`: `chronological`, `deepest_own`, `deepest_own_projected`,
  `deepest_own_projected_repeatedly`, `deepest_any`) and, with `_entry_model`, resuming with the model
  that level was entered with (`frames.model_after_lemma = Entry_model`). Each states its return even
  when it is the default, since the CAV 2026 artifact compares two of them
  (`mucyc_qsat_deepest_own_projected_repeatedly` against `mucyc_qsat_deepest_own`).
- **Pinned competition configurations** (the Athena configurations the competition wrappers under
  `script/svcomp/` and `script/termcomp/` write, and the `config/llvmfront/*.json` files they name)
  state every field of the integer reading, defaults included, so that a change of CoAR's defaults
  reaches no competition run; like the `_popl27` files they are an exception to "a file states only
  what differs" (DECISIONS.md, 2026-11-03).
- **`portfolio_<engine>_<engine>...`**: a sequential portfolio (`["Portfolio", {"stages": [...]}]`): the
  named entry configurations run one after another, each in a forked copy with its own `time_limit_s`
  (none: to the end of the run), and the first definite answer (`valid`, `invalid`, `sat`, `unsat`,
  `YES`, `NO`) is printed. `portfolio_muval_ppm_mustrat_muval_ppm` (the default
  since 2026-11-06) runs `muval_ppm` for 10 s, then `mustrat` for 60 s, then `muval_ppm`;
  `portfolio_mustrat_muval_ppm` (the default from 2026-11-05 to 2026-11-06, kept for the record) runs `mustrat`
  for 60 s, then `muval_ppm`. `portfolio_muval_qfl_native_deg1_muval` (the `qfl`/`pgcl`/`sgcl` default since
  2026-11-11) runs MuVal's QFL solver with CoAR's native PQE encoder with no limit of its own, then `muval` (PCSat)
  when that printed no definite answer; `portfolio_muval_qfl_polyqent_deg1_muval` does the same with the external
  PolyQEnt as the first stage's back end (an option). None is a paper row.
- **`dbg_` prefix**: the traced copy of the file without the prefix (tracing and the self-checks on,
  nothing else changed).
