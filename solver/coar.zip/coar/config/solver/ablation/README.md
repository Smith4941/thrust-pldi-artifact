# Ablation configurations

Each configuration here is a base configuration with one or more optimisations removed, for the
ablation studies of the papers. A name reads `<base>_no_<what is removed>`; when the base is a
paper's configuration the paper name is used (`muval_ppm_popl27_no_scc`). Run them from the
repository root like any other solver configuration, for example

```bash
./_build/default/main.exe -c ./config/solver/ablation/muval_ppm_popl27_no_scc.json -p muclp <input>
```

Nested configuration files are named relative to the repository root (`./config/...`), so a file
here reads the same nested files it would read from `config/solver/`.

Rules:

- An ablation configuration states the switch it removes and whatever its base pins; every other
  field follows CoAR's defaults, so it moves with its base when a default changes.
- Ablation configurations are not A/B candidates and are never measured against the default to
  decide a default: they show what an optimisation contributes.
- `dbg_X.json` is the traced copy of `X.json` (tracing and self-checks on, nothing else changed).

| configuration | base | removes |
| --- | --- | --- |
| `muval_ppm_popl27_no_scc` | `muval_ppm_popl27` | SCC-wise parity relations (`use_scc`) |
| `muval_ppm_popl27_no_ad` | `muval_ppm_popl27` | priority reassignment by alternation depth (`alternation_depth`) |
| `muval_ppm_popl27_no_scc_ad` | `muval_ppm_popl27` | both of the above |
| `muval_ppm_no_erasure` | `muval_ppm` | quantifier erasure (the optimizer `enable_woerq.json`) |
| `muval_ppm_no_ad_erasure` | `muval_ppm` | alternation depth and quantifier erasure |
| `muval_ppm_no_scc_ad_erasure` | `muval_ppm` | SCC, alternation depth and quantifier erasure |
| `muval_no_cycle_restriction` | `muval` | ranks every least-fixpoint predicate, not only those on a cycle (`restrict_ranking_to_cycles` off; the WF reduction's counterpart of PPM's SCC restriction) |
| `muval_no_erasure` | `muval` | quantifier erasure |
| `muval_no_cycle_restriction_erasure` | `muval` | both of the above |
| `muval_no_optimizer` | `muval` | the muCLP optimizer (`disable.json`) |
| `rcaml_no_toplevel_failure_run` | `rcaml` | the search of a failing run that evaluates the top level alone before the assertion (`toplevel_failure_run`) |
| `rcaml_no_run_search_first` | `rcaml` | the search of a failing run before the constraints are solved (`run_search_first`): an answer then comes from the constraints, which is what a check of the constraint generator needs |
| `pcsat_no_inner_skolem` | `pcsat` | the raced inner-Skolemisation probe (`probes.inner_skolem`) |
| `pcsat_no_tot_elim` | `pcsat` | solving away `Tot` predicates before the loop (`eliminate_tot_preds` in `coordinator/tbq_ar_no_tot_elim.json`) |
| `pcsat_no_fn_elim` | `pcsat` | solving away one-sided `FN` predicates before the loop (`eliminate_fn_preds` in `coordinator/tbq_ar_no_fn_elim.json`; totality elimination goes with it, since it is read only under this switch) |
| `pcsat_no_parametric_examples` | `pcsat` | parametric counterexamples, in the validator and in the graph resolver alike (`parametric_examples` in `validator/nce_no_parametric_examples.json` and `resolver/smt_no_parametric_examples.json`) |
| `mustrat_no_strategy_free_direct_race` | `mustrat` | the copy that asks a side with no strategy unknown its whole check of a verdict-only Spacer reading the printed clauses back through Z3's HORN front end (`strategy_free_race_direct_solver` = `null`) |
| `mustrat_no_one_point_split` | `mustrat` | the one-point step's game-shape extension: strict-order pairs read as disequations, a quantifier distributed over the moves of a game, the rule over the reals (`one_point_split` false, through the optimizer file `enable_erase_query_onept_no_split.json`) |
| `pcsat_no_fn_totality_consequences` | `pcsat` | the totality consequences of `FN` predicates and the functional reading that refutes a clause by instantiating its universal maps (`fn_totality_consequences` in `preprocessor/enable_no_fn_totality_consequences.json`) |

One arm **adds** a mechanism rather than removing one, for the same per-extension comparison:

| configuration | base | adds |
| --- | --- | --- |
| `pcsat_with_fn_one_point` | `pcsat` | the one-point reading of `FN` predicates (synthesizer `tbq_ar_cellguard_wide_fnop.json`, validator `nce_fnopen.json`), totality elimination kept on |
